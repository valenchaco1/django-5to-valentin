# Definición de la clase Persona
class Persona:
    # Constructor de la clase Persona con los atributos nombre, apellido y dni
    def __init__(self, nombre, apellido, dni):
        self.nombre = nombre  # Asigna el nombre proporcionado al atributo nombre de la instancia
        self.apellido = apellido  # Asigna el apellido proporcionado al atributo apellido de la instancia
        self.dni = dni  # Asigna el DNI proporcionado al atributo dni de la instancia


# Definición de la clase Empleado que hereda de Persona
class Empleado(Persona):
    # Constructor de la clase Empleado con los atributos nombre, apellido, dni y legajo
    def __init__(self, nombre, apellido, dni, legajo):
        super().__init__(nombre, apellido, dni)  # Llama al constructor de la clase base Persona
        self.legajo = legajo  # Asigna el legajo proporcionado al atributo legajo de la instancia


# Definición de la clase Cliente que hereda de Persona
class Cliente(Persona):
    # Constructor de la clase Cliente con los atributos nombre, apellido, dni y telefono
    def __init__(self, nombre, apellido, dni, telefono):    
        super().__init__(nombre, apellido, dni)  # Llama al constructor de la clase base Persona
        self.telefono = telefono  # Asigna el teléfono proporcionado al atributo telefono de la instancia


# Definición de la clase Empresa
class Empresa:
    # Constructor de la clase Empresa
    def __init__(self):
        self.empleados = []  # Inicializa una lista vacía para almacenar empleados
        self.clientes = []  # Inicializa una lista vacía para almacenar clientes


    # Método para agregar un empleado a la lista de empleados
    def agregar_empleado(self, empleado):
        self.empleados.append(empleado)  # Agrega el empleado proporcionado a la lista de empleados


    # Método para agregar un cliente a la lista de clientes
    def agregar_cliente(self, cliente):
        self.clientes.append(cliente)  # Agrega el cliente proporcionado a la lista de clientes


    # Método para visualizar la información de los empleados
    def visualizar_empleados(self):
        for empleado in self.empleados:  # Itera sobre cada empleado en la lista de empleados
            # Imprime la información del empleado
            print(f"Nombre: {empleado.nombre}, Apellido: {empleado.apellido}, DNI: {empleado.dni}, Legajo: {empleado.legajo}")


    # Método para visualizar la información de los clientes
    def visualizar_clientes(self):
        for cliente in self.clientes:  # Itera sobre cada cliente en la lista de clientes
            # Imprime la información del cliente
            print(f"Nombre: {cliente.nombre}, Apellido: {cliente.apellido}, DNI: {cliente.dni}, Teléfono: {cliente.telefono}")


# Crear una instancia de la empresa
empresa = Empresa()


# Agregar empleados
empresa.agregar_empleado(Empleado("Juan", "Perez", "30123456", "123"))
empresa.agregar_empleado(Empleado("Maria", "Gomez", "31234567", "456"))


# Agregar clientes
empresa.agregar_cliente(Cliente("Pedro", "Rodriguez", "32345678", "1122334455"))
empresa.agregar_cliente(Cliente("Sofia", "Martinez", "33456789", "2233445566"))


# Visualizar empleados
print("Empleados:")
empresa.visualizar_empleados()


# Visualizar clientes
print("\nClientes:")
empresa.visualizar_clientes()
