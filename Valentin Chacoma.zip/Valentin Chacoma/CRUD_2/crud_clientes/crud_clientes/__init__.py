import pyMysql
pymysql.install_as_MySQLdb()