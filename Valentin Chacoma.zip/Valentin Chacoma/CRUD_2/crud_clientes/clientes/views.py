from django.shortcuts import render
from django.http import HttpResponse
#from .models import clientes
#from .forms import clientesForm
# Create your views here.

def inicio(request):
    return render(request,"CRUD_2\crud_clientes\clientes\templates\pagina_base\inicio.html")