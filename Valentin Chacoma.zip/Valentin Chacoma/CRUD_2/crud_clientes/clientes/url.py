from django.urls import path

from django.urls import views
from django.conf import settings
from django.contrib.staticfiles.urls import static

urlpattern = [
    path("",views.inicio, name="inicio"),


]
