class Persona:
    def __init__(self, nombre, apellido, dni):
        self.nombre = nombre
        self.apellido = apellido
        self.dni = dni

class Empleado(Persona):
    def __init__(self, nombre, apellido, dni, legajo):
        super().__init__(nombre, apellido, dni)
        self.legajo = legajo

class Cliente(Persona):
    def __init__(self, nombre, apellido, dni, telefono):
        super().__init__(nombre, apellido, dni)
        self.telefono = telefono

class Empresa:
    def __init__(self):
        self.empleados = []
        self.clientes = []

    def agregar_empleado(self, empleado):
        self.empleados.append(empleado)

    def agregar_cliente(self, cliente):
        self.clientes.append(cliente)

    def visualizar_empleados(self):
        for empleado in self.empleados:
            print(f"Nombre: {empleado.nombre}, Apellido: {empleado.apellido}, DNI: {empleado.dni}, Legajo: {empleado.legajo}")

    def visualizar_clientes(self):
        for cliente in self.clientes:
            print(f"Nombre: {cliente.nombre}, Apellido: {cliente.apellido}, DNI: {cliente.dni}, Teléfono: {cliente.telefono}")

# Crear una instancia de la empresa
empresa = Empresa()

# Agregar empleados
empresa.agregar_empleado(Empleado("Juan", "Perez", "30123456", "123"))
empresa.agregar_empleado(Empleado("Maria", "Gomez", "31234567", "456"))

# Agregar clientes
empresa.agregar_cliente(Cliente("Pedro", "Rodriguez", "32345678", "1122334455"))
empresa.agregar_cliente(Cliente("Sofia", "Martinez", "33456789", "2233445566"))

# Visualizar empleados
print("Empleados:")
empresa.visualizar_empleados()

# Visualizar clientes
print("\nClientes:")
empresa.visualizar_clientes()
